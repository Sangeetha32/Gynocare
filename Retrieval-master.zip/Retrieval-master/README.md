# Retrieval
Hello!! Please follow the instructions before starting:

1.Copy the Gynacology_v3(given with this git folder) into AndroidStudioProjects.

2.Paste the gynoca(given with this git folder) folder in xammp/htdocs/

3.Open phpMyAdmin and create a database named "Gynaecology".

4.After creating click on the created database, in top bar, choose sql.

5.After choosing sql paste the gynaecology.sql's(given with this git folder) code in the sql blank portion.

6.Refresh the page.

7.Before starting to sync, make sure the phone and laptop must be connected to the same network.

8.You need to put up the IP Address of the network in Users/Username/AndroidStudioProjects/Gynacology_
v3/app/src/main/java/kuppam/gynacology_v3/thankyou.java and also in update_choice.java in this file.

9.Search for client.post(), you need to update your IP Address here.

10.After this you are set to sync and debug.

