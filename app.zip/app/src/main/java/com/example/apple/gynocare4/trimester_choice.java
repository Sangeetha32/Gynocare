package com.example.apple.gynocare4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.mathanky.gynocare4.R;

public class trimester_choice extends AppCompatActivity {

    Button bt1,bt2,bt3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trimester_choice);
        bt1=(Button)findViewById(R.id.button_t1);
        bt2=(Button)findViewById(R.id.button_t2);
        bt3=(Button)findViewById(R.id.button_t3);
        onBtnt1();
        onBtnt2();
        onBtnt3();
    }

    public void onBtnt1()
    {
        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),tri1_investigation.class);
                startActivity(intent);
            }
        });
    }

    public void onBtnt2()
    {
        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),tri2_investigation.class);
                startActivity(intent);
            }
        });
    }

    public void onBtnt3()
    {
        bt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),tri3_investigation.class);
                startActivity(intent);
            }
        });
    }
}
