package com.example.apple.gynocare4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.mathanky.gynocare4.R;

public class thankyou extends AppCompatActivity {

    Button btnHome;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thankyou);
        btnHome=(Button)findViewById(R.id.button2);
        onBtnHome();
    }

    @Override
    public void onBackPressed() { }

    public void onBtnHome()
    {
        btnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent("com.example.mathanky.gynocare4.generalinfo");
                startActivity(intent);
            }
        });
    }
}
