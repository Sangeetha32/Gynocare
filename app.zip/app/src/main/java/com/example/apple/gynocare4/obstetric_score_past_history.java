package com.example.apple.gynocare4;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mathanky.gynocare4.R;

import java.text.SimpleDateFormat;
import java.util.Date;
import static com.example.apple.gynocare4.generalinfo.id;
public class obstetric_score_past_history extends AppCompatActivity {

    SQLiteDatabase database;
    String table_obstetric_score="patient_id TEXT , g TEXT ,p TEXT ,a TEXT ,l TEXT ,d TEXT , update_status TEXT DEFAULT \"Not Specified\",timestamp TEXT , primary key(patient_id), foreign key(patient_id) references general_information(patient_id)";
    String table_past_obstetric_history = "patient_id TEXT ,pregnancy_order TEXT , term_preterm TEXT , mode_of_delivery TEXT , antenatal TEXT ,intrapartum TEXT ,postpartum TEXT , alive_dead TEXT , gender TEXT , baby_weight TEXT , present_age_months TEXT , present_age_days TEXT ,update_status TEXT DEFAULT \"No\", timestamp TEXT ,primary key(patient_id,pregnancy_order), foreign key(patient_id) references general_information(patient_id)";
    EditText g,p,a,l,d,preg_order,term,baby_wt,age_months,age_days;
    Button btnNext;
    RadioButton m1,m2,m3,c1,c2,s1,s2,g1,g2;
    CheckBox antenatal,intrapartum,postpartum;
    RadioGroup rg1,rg2,rg3,rg4;
    int count=1;
    //TextView t;
    String po=""+count+"";
    Button btnAdd;
    ScrollView sv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_obstetric_score_past_history);
        database = openOrCreateDatabase("gynaecology", Context.MODE_PRIVATE, null);
        database.execSQL("CREATE TABLE IF NOT EXISTS obstetric_score(" + table_obstetric_score + ")");
        database.execSQL("CREATE TABLE IF NOT EXISTS past_obstetric_history(" + table_past_obstetric_history + ")");
        rg1=(RadioGroup)findViewById(R.id.complications);
        rg2 = (RadioGroup)findViewById(R.id.mode_of_delivery);
        rg3 = (RadioGroup)findViewById(R.id.status);
        rg4 = (RadioGroup)findViewById(R.id.gender);
        g=(EditText)findViewById(R.id.G_box);
        p=(EditText)findViewById(R.id.P_box);
        a=(EditText)findViewById(R.id.A_box);
        l=(EditText)findViewById(R.id.L_box);
        d=(EditText)findViewById(R.id.D_box);
        preg_order=(EditText)findViewById(R.id.pregnancy_order);
        preg_order.setText(po);
        term=(EditText)findViewById(R.id.term);
        baby_wt=(EditText)findViewById(R.id.baby_weight);
        age_months=(EditText)findViewById(R.id.baby_age_months);
        age_days=(EditText)findViewById(R.id.baby_age_days);
        m1=(RadioButton)findViewById(R.id.vaginal);
        m2=(RadioButton)findViewById(R.id.operative_vaginal);
        m3=(RadioButton)findViewById(R.id.cesarean);
        c1=(RadioButton)findViewById(R.id.complications_yes);
        c2=(RadioButton)findViewById(R.id.complications_no);
        antenatal=(CheckBox)findViewById(R.id.antenatal);
        intrapartum=(CheckBox)findViewById(R.id.intrapartum);
        postpartum=(CheckBox)findViewById(R.id.postpartum);
        s1=(RadioButton)findViewById(R.id.alive);
        s2=(RadioButton)findViewById(R.id.dead);
        g1=(RadioButton)findViewById(R.id.male);
        g2=(RadioButton)findViewById(R.id.female);
        btnNext=(Button)findViewById(R.id.next_page5);
        btnAdd=(Button)findViewById(R.id.add_child);
        sv=(ScrollView)findViewById(R.id.scrollView1);
        //t=(TextView)findViewById(R.id.past_obs_hist_title);
        antenatal.setVisibility(View.GONE);
        intrapartum.setVisibility(View.GONE);
        postpartum.setVisibility(View.GONE);
        //onButton();

    }

    @Override
    public void onBackPressed() { }

    public void onButton(View view)
    {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
        final String format = simpleDateFormat.format(new Date());
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                if(ValidationSuccess())
                {
                    String mod="";
                    po=""+count+"";
                    preg_order.setText(po);
                    String mode_a="Not Specified";
                    String mode_i="Not Specified";
                    String mode_p="Not Specified";
                    String status="",gender="";
                    if(m1.isChecked())
                        mod="Vaginal";
                    else if(m2.isChecked())
                        mod="Operative Vaginal";
                    else if(m3.isChecked())
                        mod="Cesarean";
                    if(c1.isChecked())
                    {
                        if(antenatal.isChecked())
                            mode_a="Yes";
                        else
                            mode_a="No";
                        if(intrapartum.isChecked())
                            mode_i="Yes";
                        else
                            mode_i="No";
                        if(postpartum.isChecked())
                            mode_p="Yes";
                        else
                            mode_p="No";
                    }
                    if(s1.isChecked())
                        status="Alive";
                    else if(s2.isChecked())
                        status="Dead";
                    if(g1.isChecked())
                        gender="Male";
                    else if(g2.isChecked())
                        gender="Female";
                    String insert_obstetric_score="'" + id.toString().trim() + "'," + "'" + g.getText().toString().trim() + "'," + "'" + p.getText().toString().trim() + "'," + "'" + a.getText().toString().trim() + "'," + "'" + l.getText().toString().trim() + "'," + "'" + d.getText().toString().trim() +"','"+"No"+"','"+format.toString().trim()+"'";
                    String insert_past_obstetric_history="'" + id.toString().trim() + "'," + "'" + preg_order.getText().toString().trim() + "'," + "'" + term.getText().toString().trim() + "'," + "'" + mod.trim() + "'," + "'" + mode_a.trim() + "'," + "'" + mode_i.trim() + "'," + "'" + mode_p.trim() + "'," + "'" + status.trim() + "'," + "'" + gender.trim()+"','"+baby_wt.getText().toString().trim()+"','"+age_months.getText().toString()+"','"+ age_days.getText().toString().trim()+"','"+"No"+"','" + format.toString().trim() + "'";

                    System.out.println("InsertQuery:" + insert_obstetric_score);
                    System.out.println("InsertQuery:" + insert_past_obstetric_history);
                    //inserting into database
                    database.execSQL("INSERT INTO obstetric_score VALUES (" + insert_obstetric_score + ")");
                    database.execSQL("INSERT INTO past_obstetric_history VALUES (" +insert_past_obstetric_history+" )");
                    Toast.makeText(getApplicationContext(), "Successful", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getApplicationContext(), histories.class);
                    startActivity(intent);

                }
                else
                {
                    Toast.makeText(getApplicationContext(), "Please check the details", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
    public void onAddChild(View view)
    {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
        final String format = simpleDateFormat.format(new Date());
        if(ValidationSuccess()) {
            String mod = "";
            String mode_a = "Not Specified";
            String mode_i = "Not Specified";
            String mode_p = "Not Specified";
            String status = "", gender = "";
            if (m1.isChecked())
                mod = "Vaginal";
            else if (m2.isChecked())
                mod = "Operative Vaginal";
            else if (m3.isChecked())
                mod = "Cesarean";
            if (c1.isChecked()) {
                if (antenatal.isChecked())
                    mode_a = "Yes";
                else
                    mode_a = "No";
                if (intrapartum.isChecked())
                    mode_i = "Yes";
                else
                    mode_i = "No";
                if (postpartum.isChecked())
                    mode_p = "Yes";
                else
                    mode_p = "No";
            }
            if (s1.isChecked())
                status = "Alive";
            else if (s2.isChecked())
                status = "Dead";
            if (g1.isChecked())
                gender = "Male";
            else if (g2.isChecked())
                gender = "Female";
            String insert_past_obstetric_history = "'" + id.toString().trim() + "'," + "'" + preg_order.getText().toString().trim() + "'," + "'" + term.getText().toString().trim() + "'," + "'" + mod.trim() + "'," + "'" + mode_a.trim() + "'," + "'" + mode_i.trim() + "'," + "'" + mode_p.trim() + "'," + "'" + status.trim() + "'," + "'" + gender.trim() + "','" + baby_wt.getText().toString().trim() + "','" + age_months.getText().toString() + "','" + age_days.getText().toString().trim() + "','" + "No" + "','" + format.toString().trim() + "'";
            System.out.println("InsertQuery:" + insert_past_obstetric_history);
            database.execSQL("INSERT INTO past_obstetric_history VALUES (" + insert_past_obstetric_history + " )");
            count=count+1;
            po=""+count+"";
            preg_order.setText(po);
            term.setText("");
            baby_wt.setText("");
            age_months.setText("");
            age_days.setText("");
            rg1.clearCheck();
            rg2.clearCheck();
            rg3.clearCheck();
            rg4.clearCheck();
            if(antenatal.isChecked())
                antenatal.setChecked(false);
            if(intrapartum.isChecked())
                intrapartum.setChecked(false);
            if(postpartum.isChecked())
                postpartum.setChecked(false);
            focusOnView();
        }
    }

    private final void focusOnView(){
        sv.post(new Runnable() {
            @Override
            public void run() {
                sv.scrollTo(0,d.getBottom());
            }
        });
    }

    private boolean ValidationSuccess(){

        boolean check=true;
        StringBuilder errMsg = new StringBuilder("");
        if (g.getText().toString().equalsIgnoreCase("")){
            g.setError("Please enter a value");
            check=false;
        }

        if (p.getText().toString().equalsIgnoreCase("")){
            p.setError("Please enter a value");
            check=false;
        }

        if (a.getText().toString().equalsIgnoreCase("")){
            a.setError("Please enter a value");
            check=false;
        }

        if (l.getText().toString().equalsIgnoreCase("")){
            l.setError("Please enter a value");
            check=false;
        }

        if (d.getText().toString().equalsIgnoreCase("")){
            d.setError("Please enter a value");
            check=false;
        }

        if (term.getText().toString().equalsIgnoreCase("")){
            term.setError("Please enter a value");
            check=false;
        }

        if (baby_wt.getText().toString().equalsIgnoreCase("")){
            baby_wt.setError("Please enter a value");
            check=false;
        }

        if (age_days.getText().toString().equalsIgnoreCase("")){
            age_days.setError("Please enter a value");
            check=false;
        }

        if (Integer.parseInt(age_days.getText().toString())>31){
            age_days.setError("Exceeds limit! Please enter a valid number of days less than 31");
            return false;
        }


        if (age_months.getText().toString().equalsIgnoreCase("")){
            age_months.setError("Please enter a value");
            check=false;
        }



        if (rg1.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg2.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg3.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg4.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if(c1.isChecked())
        {
            if (!(antenatal.isChecked() || intrapartum.isChecked() || postpartum.isChecked())){
                antenatal.setError("Please select an option");
                check=false;
            }

        }
        return check;
    }

    public void click(View view)
    {
        antenatal.setVisibility(View.VISIBLE);
        intrapartum.setVisibility(View.VISIBLE);
        postpartum.setVisibility(View.VISIBLE);
    }

    public void click1(View view)
    {
        antenatal.setVisibility(View.GONE);
        intrapartum.setVisibility(View.GONE);
        postpartum.setVisibility(View.GONE);
    }

}
