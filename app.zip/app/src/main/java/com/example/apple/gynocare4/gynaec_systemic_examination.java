package com.example.apple.gynocare4;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.mathanky.gynocare4.R;

import java.text.SimpleDateFormat;
import java.util.Date;
import static com.example.apple.gynocare4.generalinfo.id;
public class gynaec_systemic_examination extends AppCompatActivity {
    Button btnNext2;
    EditText e,e1,e2,e3,e4,e5,e6, e7, e8, e9,e10,e11,e12;
    RadioGroup rg1, rg2, rg3;
    RadioButton selectedRadioButton, sr2, sr3;
    //String id="1234";
    SQLiteDatabase database;
    String table_query = "patient_id TEXT ," +
            "gynaec_cvs TEXT ," +
            "gynaec_rs TEXT ," +
            "gynaec_cns TEXT ," +
            "gynaec_inspection TEXT ," +
            "gynaec_palpation TEXT ," +
            "gynaec_percussion TEXT ," +
            "gynaec_auscultation TEXT ," +
            "gynaec_local_examination TEXT ," +
            "gynaec_speculum_examination TEXT ," +
            "gynaec_bimanual_examination TEXT ," +
            "gynaec_rectal_examination TEXT ," +
            "gynaec_provisional_diagnosis TEXT ," +
            "update_status TEXT DEFAULT \"No\"," +
            "timestamp TEXT ," +
            "primary key(patient_id)," +
            "foreign key(patient_id) references general_information(patient_id)";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gynaec_systemic_examination);

        e1 = (EditText)findViewById(R.id.g_CVS_box) ;
        e2 = (EditText)findViewById(R.id.g_RS_box) ;
        e3 = (EditText)findViewById(R.id.g_CNS_box) ;
        e4=(EditText)findViewById(R.id.g_inspection);
        e5=(EditText)findViewById(R.id.g_palpitation);
        e6=(EditText)findViewById(R.id.g_percussion);
        e7=(EditText)findViewById(R.id.g_ascultation);
        e8=(EditText)findViewById(R.id.g_local_examination);
        e9=(EditText)findViewById(R.id.g_speculum_examination);
        e10=(EditText)findViewById(R.id.g_bimanual_examination);
        e11=(EditText)findViewById(R.id.g_rectal_examination);
        e12=(EditText)findViewById(R.id.g_provisional_diagnosis);
        rg2 = (RadioGroup)findViewById(R.id.g_RS);
        sr2 = (RadioButton)findViewById(R.id.g_RS_abnormal);
        rg3 = (RadioGroup)findViewById(R.id.g_CNS);
        sr3 = (RadioButton)findViewById(R.id.g_CNS_abnormal);
        rg1=(RadioGroup)findViewById(R.id.g_CVS);
        selectedRadioButton = (RadioButton)findViewById(R.id.g_CVS_abnormal);
        e1.setVisibility(View.GONE);
        e2.setVisibility(View.GONE);
        e3.setVisibility(View.GONE);
        //opening db
        database = openOrCreateDatabase("gynaecology", Context.MODE_PRIVATE, null);

        //creating table if doesn't exist
        //database.execSQL("DROP TABLE systemic_examination");
        database.execSQL("CREATE TABLE IF NOT EXISTS gynaec_systemic_examination (" + table_query + ")");

    }

    @Override
    public void onBackPressed() { }

    public void onProceed(View view) {
        if (ValidationSuccess()) {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
            String format = simpleDateFormat.format(new Date());
            String cvs="Normal",rs="Normal",cns="Normal";
            if(selectedRadioButton.isChecked())
                cvs=e1.getText().toString().trim();
            if(sr2.isChecked())
                rs=e2.getText().toString().trim();
            if(sr3.isChecked())
                cns=e3.getText().toString().trim();
            String insert_query ="'" + id.toString().trim() + "'," +
                    "'" + cvs + "'," +
                    "'" + rs + "'," +
                    "'" + cns + "'," +
                    "'"+e4.getText().toString().trim()+"',"+
                    "'"+e5.getText().toString().trim()+"',"+
                    "'"+e6.getText().toString().trim()+"',"+
                    "'"+e7.getText().toString().trim()+"',"+
                    "'"+e8.getText().toString().trim()+"',"+
                    "'"+e9.getText().toString().trim()+"',"+
                    "'"+e10.getText().toString().trim()+"',"+
                    "'"+e11.getText().toString().trim()+"',"+
                    "'"+e12.getText().toString().trim()+"',"+
                    "'" + "No" + "'," +
                    "'" + format.toString().trim() + "'";
            System.out.println("InsertQuery:" + insert_query);
            //inserting into database
            database.execSQL("INSERT INTO gynaec_systemic_examination VALUES (" + insert_query + ")");
            Toast.makeText(getApplicationContext(), "Successful", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(getApplicationContext(), gynaec_investigations.class);
            startActivity(intent);

        } else {
            Toast.makeText(getApplicationContext(), "Please check the details", Toast.LENGTH_LONG).show();
        }
        database.close();

    }
    private boolean ValidationSuccess(){

        boolean check=true;
        StringBuilder errMsg = new StringBuilder("");
        if (rg1.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg2.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg3.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if(selectedRadioButton.isChecked())
        {
            e1 = (EditText)findViewById(R.id.g_CVS_box) ;
            if (e1.getText().toString().equalsIgnoreCase("")){
                e1.setError("Please enter a value");
                check=false;
            }
        }

        if(sr2.isChecked())
        {
            e2 = (EditText)findViewById(R.id.g_RS_box) ;
            if (e2.getText().toString().equalsIgnoreCase("")){
                e2.setError("Please enter a value");
                check=false;
            }
        }

        if(sr3.isChecked())
        {
            e3 = (EditText)findViewById(R.id.g_CNS_box) ;
            if (e3.getText().toString().equalsIgnoreCase("")){
                e3.setError("Please enter a value");
                check=false;
            }
        }

        e = (EditText)findViewById(R.id.g_inspection) ;
        if (e.getText().toString().equalsIgnoreCase("")){
            e.setError("Please enter a value");
            check=false;
        }

        e = (EditText)findViewById(R.id.g_palpitation) ;
        if (e.getText().toString().equalsIgnoreCase("")){
            e.setError("Please enter a value");
            check=false;
        }

        e = (EditText)findViewById(R.id.g_ascultation) ;
        if (e.getText().toString().equalsIgnoreCase("")){
            e.setError("Please enter a value");
            check=false;
        }

        e = (EditText)findViewById(R.id.g_percussion) ;
        if (e.getText().toString().equalsIgnoreCase("")){
            e.setError("Please enter a value");
            check=false;
        }

        e = (EditText)findViewById(R.id.g_speculum_examination) ;
        if (e.getText().toString().equalsIgnoreCase("")){
            e.setError("Please enter a value");
            check=false;
        }

        e = (EditText)findViewById(R.id.g_local_examination) ;
        if (e.getText().toString().equalsIgnoreCase("")){
            e.setError("Please enter a value");
            check=false;
        }

        e = (EditText)findViewById(R.id.g_bimanual_examination) ;
        if (e.getText().toString().equalsIgnoreCase("")){
            e.setError("Please enter a value");
            check=false;
        }

        e = (EditText)findViewById(R.id.g_rectal_examination) ;
        if (e.getText().toString().equalsIgnoreCase("")){
            e.setError("Please enter a value");
            check=false;
        }

        e = (EditText)findViewById(R.id.g_provisional_diagnosis) ;
        if (e.getText().toString().equalsIgnoreCase("")){
            e.setError("Please enter a value");
            check=false;
        }


        return check;
    }
    public void click(View view) {
        e1 = (EditText) findViewById(R.id.g_CVS_box);
        e1.setVisibility(View.VISIBLE);
    }

    public void click1(View view) {
        e1 = (EditText) findViewById(R.id.g_CVS_box);
        e1.setVisibility(View.GONE);
    }

    public void click2(View view) {
        e1 = (EditText) findViewById(R.id.g_RS_box);
        e1.setVisibility(View.VISIBLE);
    }

    public void click3(View view) {
        e1 = (EditText) findViewById(R.id.g_RS_box);
        e1.setVisibility(View.GONE);
    }

    public void click4(View view) {
        e1 = (EditText) findViewById(R.id.g_CNS_box);
        e1.setVisibility(View.VISIBLE);
    }

    public void click5(View view) {
        e1 = (EditText) findViewById(R.id.g_CNS_box);
        e1.setVisibility(View.GONE);
    }



}
