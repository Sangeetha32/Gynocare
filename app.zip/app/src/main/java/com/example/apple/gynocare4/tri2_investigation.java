package com.example.apple.gynocare4;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.mathanky.gynocare4.R;

import java.text.SimpleDateFormat;
import java.util.Date;
import static com.example.apple.gynocare4.generalinfo.id;
public class tri2_investigation extends AppCompatActivity {

    SQLiteDatabase database;
    EditText e2;
    EditText second_other_box, second_hb, rbs;
    RadioGroup rg1, rg2, rg3, rg4, rg5, rg6, rg7, rg8;
    RadioButton selectedRadioButton,b1,b2,b3,b4,b5,b6,b7,b8,a1,a2,s1,s2,m1,m2,v1,v2,h1,h2,hbs1,hbs2;
    CheckBox quickening, bleeding_piv, leak_piv, pih, tt, iron,calc, second_other;
    String bgrt="",
            q="Not Specified",
            bp="Not Specified",
            lp="Not Specified",
            p="Not Specified",
            t="Not Specified",
            i="Not Specified",
            c="Not Specified",
            so="Not Specified",
            sc="",
            trimesterNo="Trimester-2",
            a="",
            s="",
            m="",
            vdrl="",
            hiv="",
            hbsag="";

    String table_query1 = "patient_id TEXT NOT NULL," +
            "quickening TEXT DEFAULT \"Not Specified\"," +
            " history_of_bleeding_piv TEXT DEFAULT \"Not Specified\"," +
            "leak_piv1 TEXT DEFAULT \"Not Specified\"," +
            "pih_history1 TEXT DEFAULT \"Not Specified\"," +
            "tt TEXT DEFAULT \"Not Specified\"," +
            " iron_tablets1 TEXT DEFAULT \"Not Specified\"," +
            " calcium_tablets1 TEXT DEFAULT \"Not Specified\"," +
            " others2 TEXT DEFAULT \"Not Specified\"," +
            "anomaly_scan TEXT NOT NULL," +
            "update_status TEXT DEFAULT \"No\"," +
            "timestamp TEXT NOT NULL," +
            "primary key(patient_id), foreign key(patient_id) references general_information(patient_id)";
    String table_query2 = "patient_id TEXT NOT NULL," +
            "trimester_number TEXT NOT NULL," +
            " hb TEXT NOT NULL, " +
            "blood_grouping_rh_typing TEXT NOT NULL, " +
            "albumin TEXT NOT NULL," +
            " sugar TEXT NOT NULL," +
            " microscopy TEXT NOT NULL," +
            " vdrl TEXT NOT NULL," +
            " hiv_status TEXT NOT NULL," +
            " hbsag TEXT NOT NULL," +
            " rbs TEXT NOT NULL," +
            " others4 TEXT DEFAULT \"Not Specified\"," +
            " update_status TEXT DEFAULT \"No\"," +
            "timestamp TEXT NOT NULL," +
            "primary key(patient_id, trimester_number), foreign key(patient_id) references general_information(patient_id)";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tri2_investigation);
        e2 = (EditText)findViewById(R.id.second_trimester_others);
        quickening = (CheckBox) findViewById(R.id.quickening);
        bleeding_piv = (CheckBox) findViewById(R.id.bleeding_piv);
        leak_piv = (CheckBox) findViewById(R.id.leak_piv);
        pih = (CheckBox) findViewById(R.id.pih);
        calc = (CheckBox)findViewById(R.id.calcium);
        tt = (CheckBox) findViewById(R.id.tt);
        iron = (CheckBox) findViewById(R.id.iron);

        second_other = (CheckBox) findViewById(R.id.second_other);
        second_other_box = (EditText)findViewById(R.id.second_other_box);

        second_other_box.setVisibility(View.GONE);
        quickening.setVisibility(View.GONE);
        bleeding_piv.setVisibility(View.GONE);
        leak_piv.setVisibility(View.GONE);
        pih.setVisibility(View.GONE);
        tt.setVisibility(View.GONE);
        calc.setVisibility(View.GONE);
        iron.setVisibility(View.GONE);
        second_other.setVisibility(View.GONE);

        second_hb = (EditText)findViewById(R.id.second_hb) ;
        rg2 = (RadioGroup)findViewById(R.id.second_albumin);
        rg3 = (RadioGroup)findViewById(R.id.second_sugar);
        rg4 = (RadioGroup)findViewById(R.id.second_microscopy);
        rg5 = (RadioGroup)findViewById(R.id.second_vdrl);
        rg6 = (RadioGroup)findViewById(R.id.second_hiv);
        rg7 = (RadioGroup)findViewById(R.id.second_hbsag);
        rg8 =  (RadioGroup)findViewById(R.id.second_blood_group);
        rbs = (EditText)findViewById(R.id.second_rbs);
        rg1=(RadioGroup)findViewById(R.id.second_trimester_complaints);
        selectedRadioButton = (RadioButton)findViewById(R.id.second_trimester_complaints_yes);
        b1 = (RadioButton)findViewById(R.id.second_blood_group_A_plus);
        b2 = (RadioButton)findViewById(R.id.second_blood_group_A_minus);
        b3 = (RadioButton)findViewById(R.id.second_blood_group_B_plus);
        b4 = (RadioButton)findViewById(R.id.second_blood_group_B_minus);
        b5 = (RadioButton)findViewById(R.id.second_blood_group_O_plus);
        b6 = (RadioButton)findViewById(R.id.second_blood_group_O_minus);
        b7 = (RadioButton)findViewById(R.id.second_blood_group_AB_plus);
        b8 = (RadioButton)findViewById(R.id.second_blood_group_AB_minus);
        e2 = (EditText)findViewById(R.id.second_trimester_others);
        quickening = (CheckBox) findViewById(R.id.quickening);
        bleeding_piv = (CheckBox) findViewById(R.id.bleeding_piv);
        leak_piv = (CheckBox) findViewById(R.id.leak_piv);
        pih = (CheckBox) findViewById(R.id.pih);
        calc = (CheckBox)findViewById(R.id.calcium);
        tt = (CheckBox) findViewById(R.id.tt);
        iron = (CheckBox) findViewById(R.id.iron);
        second_other = (CheckBox) findViewById(R.id.second_other);
        second_other_box = (EditText) findViewById(R.id.second_other_box);
        a1=(RadioButton)findViewById(R.id.second_albumin_normal);
        a2=(RadioButton)findViewById(R.id.second_albumin_abnormal);
        s1=(RadioButton)findViewById(R.id.second_sugar_normal);
        s2=(RadioButton)findViewById(R.id.second_sugar_abnormal);
        m1=(RadioButton)findViewById(R.id.second_microscopy_normal);
        m2=(RadioButton)findViewById(R.id.second_microscopy_abnormal);
        v1=(RadioButton)findViewById(R.id.second_vdrl_reactive);
        v2=(RadioButton)findViewById(R.id.second_vdrl_non_reactive);
        h1=(RadioButton)findViewById(R.id.second_hiv_reactive);
        h2=(RadioButton)findViewById(R.id.second_hiv_non_reactive);
        hbs1=(RadioButton)findViewById(R.id.second_hbsag_reactive);
        hbs2=(RadioButton)findViewById(R.id.second_hbsag_non_reactive);
        rbs=(EditText)findViewById(R.id.second_rbs);
        // Is the button now checked?
        //opening db
        database = openOrCreateDatabase("gynaecology", Context.MODE_PRIVATE, null);

        //creating table if doesn't exist
        database.execSQL("CREATE TABLE IF NOT EXISTS second_trimester(" + table_query1 + ")");
        database.execSQL("CREATE TABLE IF NOT EXISTS investigations(" + table_query2 + ")");
    }
    @Override
    public void onBackPressed() {
    }

    public void onProceed(View view){
        if(ValidationSuccess()){
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
            String format = simpleDateFormat.format(new Date());
            if(selectedRadioButton.isChecked()) {
                if (quickening.isChecked()) {
                    q = "Yes";
                } else {
                    q = "No";
                }
                if (bleeding_piv.isChecked()) {
                    bp = "Yes";
                } else {
                    bp = "No";
                }
                if (leak_piv.isChecked()) {
                    lp = "Yes";
                } else {
                    lp = "No";
                }
                if (pih.isChecked()) {
                    p = "Yes";
                } else {
                    p = "No";
                }
                if (tt.isChecked()) {
                    t = "Yes";
                } else {
                    t = "No";
                }
                if (iron.isChecked()) {
                    i = "Yes";
                } else {
                    i = "No";
                }
                if (calc.isChecked()) {
                    c = "Yes";
                } else {
                    c = "No";
                }
                if (second_other.isChecked()) {
                    so = second_other_box.getText().toString();
                } else {
                    so = "No";
                }
            }
            String insert_query1 = "'" + id.toString().trim() + "'," +
                    "'" + q + "'," +
                    "'" + bp + "'," +
                    "'" + lp + "'," +
                    "'" + p + "'," +
                    "'" + t + "'," +
                    "'" + i + "'," +
                    "'" + c + "'," +
                    "'" + so + "'," +
                    "'" + sc +"',"+
                    "'" + "No" + "'," +
                    "'" + format.trim() + "'";
            String insert_query2 = "'" + id.toString().trim() + "'," +
                    "'" + trimesterNo + "'," +
                    "'" + second_hb.getText().toString().trim() + "'," +
                    "'" + bgrt + "'," +
                    "'" + a + "'," +
                    "'" + s + "'," +
                    "'" + m + "'," +
                    "'" + vdrl + "'," +
                    "'" + hiv + "'," +
                    "'" + hbsag + "'," +
                    "'" + rbs.getText().toString().trim() + "'," +
                    "'" + e2.getText().toString().trim() + "'," +
                    "'" + "No" + "'," +
                    "'" + format.trim() + "'";
            System.out.println("InsertQuery:" + insert_query1);
            System.out.println("InsertQuery:" + insert_query2);
            //inserting into database
            database.execSQL("INSERT INTO second_trimester VALUES (" + insert_query1 + ")");
            database.execSQL("INSERT INTO investigations VALUES (" + insert_query2 + ")");
            Toast.makeText(getApplicationContext(), "Successful", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(getApplicationContext(), obstetric_score_past_history.class);
            startActivity(intent);
        }else{
            Toast.makeText(getApplicationContext(), "Please check the details", Toast.LENGTH_LONG).show();
        }
        database.close();
    }

    private boolean ValidationSuccess(){

        boolean check=true;
        StringBuilder errMsg = new StringBuilder("");

        if (second_hb.getText().toString().equalsIgnoreCase("")){
            second_hb.setError("Please enter a value");
            check=false;
        }

        if (Integer.parseInt(second_hb.getText().toString()) > 100) {
            second_hb.setError("Exceeds limit! Please enter a valid percentage");
            return false;
        }

        if (rbs.getText().toString().equalsIgnoreCase("")){
            rbs.setError("Please enter a value");
            check=false;
        }

        if (rg1.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg2.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg3.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg4.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg5.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg6.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg7.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg8.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }


        if(selectedRadioButton.isChecked())
        {
            if (!(quickening.isChecked() || bleeding_piv.isChecked() || leak_piv.isChecked() || pih.isChecked() || tt.isChecked() || iron.isChecked()||calc.isChecked() || second_other.isChecked())){
                quickening.setError("Please select an option");
                check=false;
            }


            else if(second_other.isChecked()&& second_other_box.getText().toString().equalsIgnoreCase("")){
                second_other.setError("Please enter a value");
                check=false;
            }

        }
        return check;
    }

    public void onclickAssign(View view)
    {
        if(b1.isChecked())
            bgrt="A+";
        else if(b2.isChecked())
            bgrt="A-";
        else if(b3.isChecked())
            bgrt="B+";
        else if(b4.isChecked())
            bgrt="B-";
        else if(b5.isChecked())
            bgrt="O+";
        else if(b6.isChecked())
            bgrt="O-";
        else if(b7.isChecked())
            bgrt="AB+";
        else if(b8.isChecked())
            bgrt="AB-";
    }

    public void click(View view)
    {
        quickening.setVisibility(View.VISIBLE);
        bleeding_piv.setVisibility(View.VISIBLE);
        leak_piv.setVisibility(View.VISIBLE);
        pih.setVisibility(View.VISIBLE);
        tt.setVisibility(View.VISIBLE);
        calc.setVisibility(View.VISIBLE);
        iron.setVisibility(View.VISIBLE);
        second_other.setVisibility(View.VISIBLE);

    }

    public void click3(View view)
    {
        second_other_box = (EditText)findViewById(R.id.second_other_box);
        second_other_box.setVisibility(View.VISIBLE);

    }
    public void click1(View view)
    {
        second_other_box.setVisibility(View.GONE);
        quickening.setVisibility(View.GONE);
        bleeding_piv.setVisibility(View.GONE);
        leak_piv.setVisibility(View.GONE);
        pih.setVisibility(View.GONE);
        tt.setVisibility(View.GONE);
        calc.setVisibility(View.GONE);
        iron.setVisibility(View.GONE);
        second_other.setVisibility(View.GONE);

    }

    public void onclickAssign3(View view)
    {
        if(a1.isChecked())
            a="Normal";
        if(s1.isChecked())
            s="Normal";
        if(m1.isChecked())
            m="Normal";
        if(v1.isChecked())
            vdrl="Reactive";
        if(h1.isChecked())
            hiv="Reactive";
        if(hbs1.isChecked())
            hbsag="Reactive";
    }
}