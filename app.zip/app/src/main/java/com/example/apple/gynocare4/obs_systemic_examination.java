package com.example.apple.gynocare4;


import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.mathanky.gynocare4.R;
import com.example.apple.gynocare4.thankyou;

import java.text.SimpleDateFormat;
import java.util.Date;

import static com.example.apple.gynocare4.generalinfo.id;
public class obs_systemic_examination extends AppCompatActivity {

    SQLiteDatabase database;
    String table_systemic_examination="patient_id TEXT ,cvs TEXT , rs TEXT , cns TEXT , uterine_size TEXT , presentation TEXT , fhs TEXT , liquor TEXT , previous_scar TEXT ,update_status TEXT DEFAULT \"No\", timestamp TEXT , primary key(patient_id), foreign key(patient_id) references general_information(patient_id)";
    EditText cvs_box, rs_box, cns_box, uterine_box,previous_scar_box;
    RadioButton cvs1,cvs2,rs1,rs2,cns1,cns2,p1,p2,p3,fhs1,fhs2,fhsp1,fhsp2,fhsp3,l1,l2,l3,ps1,ps2;
    RadioGroup rg1,rg2,rg3,rg4,rg5,rg6,rg7,rg11;
    Button btnNext;

    @Override
    public void onBackPressed() { }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_obs_systemic_examination);
        database = openOrCreateDatabase("gynaecology", Context.MODE_PRIVATE, null);
        database.execSQL("CREATE TABLE IF NOT EXISTS systemic_examination(" + table_systemic_examination + ")");
        cvs1=(RadioButton)findViewById(R.id.cvs_normal);
        cvs2=(RadioButton)findViewById(R.id.cvs_abnormal);
        rs1=(RadioButton)findViewById(R.id.rs_normal);
        rs2=(RadioButton)findViewById(R.id.rs_abnormal);
        cns1=(RadioButton)findViewById(R.id.cns_normal);
        cns2=(RadioButton)findViewById(R.id.cns_abnormal);
        p1=(RadioButton)findViewById(R.id.cephalic);
        p2=(RadioButton)findViewById(R.id.breech);
        p3=(RadioButton)findViewById(R.id.transverse);
        fhs1=(RadioButton)findViewById(R.id.fhs_plus);
        fhs2=(RadioButton)findViewById(R.id.fhs_minus);
        fhsp1=(RadioButton)findViewById(R.id.fhs_single);
        fhsp2=(RadioButton)findViewById(R.id.fhs_double);
        fhsp3=(RadioButton)findViewById(R.id.fhs_triple);
        l1=(RadioButton)findViewById(R.id.adequate);
        l2=(RadioButton)findViewById(R.id.reduced);
        l3=(RadioButton)findViewById(R.id.excess);
        ps1=(RadioButton)findViewById(R.id.previous_scar_present);
        ps2=(RadioButton)findViewById(R.id.previous_scar_absent);
        cvs_box=(EditText)findViewById(R.id.cvs_box);
        rs_box=(EditText)findViewById(R.id.rs_box);
        cns_box=(EditText)findViewById(R.id.cns_box);
        uterine_box=(EditText)findViewById(R.id.uterine_size);
        previous_scar_box=(EditText)findViewById(R.id.previous_scar_box);
        rg1=(RadioGroup)findViewById(R.id.cvs);
        rg2 = (RadioGroup)findViewById(R.id.rs);
        rg3 = (RadioGroup)findViewById(R.id.cns);
        rg4 = (RadioGroup)findViewById(R.id.presentation);
        rg5 = (RadioGroup)findViewById(R.id.fhs);
        rg6 = (RadioGroup)findViewById(R.id.liquor);
        rg7 = (RadioGroup)findViewById(R.id.previous_scar);
        rg11 = (RadioGroup)findViewById(R.id.fhs_positive);
        cns_box.setVisibility(View.GONE);
        cvs_box.setVisibility(View.GONE);
        rs_box.setVisibility(View.GONE);
        previous_scar_box.setVisibility(View.GONE);
        rg11.setVisibility(View.GONE);
        btnNext=(Button)findViewById(R.id.next_page8);
        onButton();
    }
    private boolean ValidationSuccess(){

        boolean check=true;
        StringBuilder errMsg = new StringBuilder("");
        if (uterine_box.getText().toString().equalsIgnoreCase("")){
            uterine_box.setError("Please enter a value");
            check=false;
        }

        if (rg1.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg2.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg3.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg4.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg5.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg6.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg7.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }


        if(cvs2.isChecked())
        {
            if (cvs_box.getText().toString().equalsIgnoreCase("")){
                cvs_box.setError("Please enter a value");
                check=false;
            }
        }

        if(rs2.isChecked())
        {
            if (rs_box.getText().toString().equalsIgnoreCase("")){
                rs_box.setError("Please enter a value");
                check=false;
            }
        }

        if(cns2.isChecked())
        {
            if (cns_box.getText().toString().equalsIgnoreCase("")){
                cns_box.setError("Please enter a value");
                check=false;
            }
        }


        if(fhs1.isChecked())
        {
            if (rg11.getCheckedRadioButtonId() == -1)
            {
                errMsg.append("Please select on option\n");
                check=false;
            }
        }


        if(ps1.isChecked())
        {
            if (previous_scar_box.getText().toString().equalsIgnoreCase("")){
                previous_scar_box.setError("Please enter a value");
                check=false;
            }
        }
        return check;
    }

    public void onButton()
    {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
        final String format = simpleDateFormat.format(new Date());
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(ValidationSuccess())
                {
                    String cvs="Normal",rs="Normal",cns="Normal",fhs="Absent",prev_scar="Absent";
                    String pres="",liq="";
                    if(cvs2.isChecked())
                        cvs=cvs_box.getText().toString();
                    if(rs2.isChecked())
                        rs=rs_box.getText().toString();
                    if(cns2.isChecked())
                        cns=cns_box.getText().toString();
                    if(ps1.isChecked())
                        prev_scar=previous_scar_box.getText().toString();
                    if(p1.isChecked())
                        pres="Cephalic";
                    else if(p2.isChecked())
                        pres="Breech";
                    else if(p3.isChecked())
                        pres="Transverse";
                    if(l1.isChecked())
                        liq="Adequate";
                    else if(l2.isChecked())
                        liq="Reduced";
                    else if(l3.isChecked())
                        liq="Excess";
                    if(fhs1.isChecked())
                    {
                        if(fhsp1.isChecked())
                            fhs="+";
                        else if(fhsp2.isChecked())
                            fhs="++";
                        else if(fhsp3.isChecked())
                            fhs="+++";
                    }
                    String insert_systemic_examination="'"+id.toString().trim()+"','"+cvs.trim()+"','"+rs.trim()+"','"+cns.trim()+"','"+uterine_box.getText().toString().trim()+"','"+pres.trim()+"','"+fhs.trim()+"','"+liq.trim()+"','"+prev_scar.trim()+"',"+ "'" + "No" + "',"  + "'" + format.toString().trim() + "'";
                    System.out.println("InsertQuery:" + insert_systemic_examination);
                    //inserting into database
                    database.execSQL("INSERT INTO systemic_examination VALUES (" + insert_systemic_examination + ")");
                    Toast.makeText(getApplicationContext(), "Successful", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getApplicationContext(), thankyou.class);
                    startActivity(intent);

                }
                else
                {
                    Toast.makeText(getApplicationContext(), "Please check the details", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void click(View view)
    {
        cvs_box.setVisibility(View.VISIBLE);
    }

    public void click1(View view)
    {
        cvs_box.setVisibility(View.GONE);
    }

    public void click2(View view)
    {
        rs_box.setVisibility(View.VISIBLE);
    }

    public void click3(View view)
    {
        rs_box.setVisibility(View.GONE);
    }

    public void click4(View view)
    {
        cns_box.setVisibility(View.VISIBLE);
    }

    public void click5(View view)
    {
        cns_box.setVisibility(View.GONE);
    }

    public void click8(View view)
    {
        previous_scar_box.setVisibility(View.VISIBLE);
    }

    public void click9(View view)
    {
        previous_scar_box.setVisibility(View.GONE);
    }

    public void click6(View view)
    {
        rg11 = (RadioGroup)findViewById(R.id.fhs_positive);
        rg11.setVisibility(View.VISIBLE);
    }

    public void click7(View view)
    {
        rg11 = (RadioGroup)findViewById(R.id.fhs_positive);
        rg11.setVisibility(View.GONE);
    }

}
