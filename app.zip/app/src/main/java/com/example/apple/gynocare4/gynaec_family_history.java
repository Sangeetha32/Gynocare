package com.example.apple.gynocare4;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.mathanky.gynocare4.R;
import com.example.apple.gynocare4.personal_history13;

import java.text.SimpleDateFormat;
import java.util.Date;
import static com.example.apple.gynocare4.generalinfo.id;
public class gynaec_family_history extends AppCompatActivity {
    EditText d_box,h_box,t_box,m_box,others;
    RadioGroup rg1, rg2, rg3, rg4;
    RadioButton d1,h1,t1,m1;
    SQLiteDatabase database;
    //String id="1234";
    String table_query = "patient_id TEXT ," +
            "gynaec_diabetes2 TEXT ," +
            "gynaec_hypertension2 TEXT ," +
            "gynaec_tb2 TEXT ," +
            "gynaec_malignancy TEXT ," +
            "gynaec_others6 TEXT ," +
            "update_status TEXT DEFAULT \"No\"," +
            "timestamp TEXT ," +
            "primary key(patient_id)," +
            "foreign key(patient_id) references general_information(patient_id)";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gynaec_family_history);
        d_box= (EditText)findViewById(R.id.g_diabetes_family_box) ;
        h_box= (EditText)findViewById(R.id.g_hyper_family_box) ;
        t_box= (EditText)findViewById(R.id.g_family_tb_box) ;
        m_box = (EditText)findViewById(R.id.g_malignacy_box) ;
        others= (EditText)findViewById(R.id.g_complaints_oi_2) ;
        d1=(RadioButton) findViewById(R.id.g_dia_family_yes);
        h1=(RadioButton)findViewById(R.id.g_hyper_family_yes);
        t1=(RadioButton)findViewById(R.id.g_family_tb_yes);
        m1=(RadioButton)findViewById(R.id.g_malignacy_yes);
        rg2 = (RadioGroup)findViewById(R.id.g_hyper_family);
        rg3 = (RadioGroup)findViewById(R.id.g_family_tb);
        rg4 = (RadioGroup)findViewById(R.id.g_malignacy);
        rg1=(RadioGroup)findViewById(R.id.g_diabetes_family);
        d_box.setVisibility(View.GONE);
        h_box.setVisibility(View.GONE);
        t_box.setVisibility(View.GONE);
        m_box.setVisibility(View.GONE);
        //opening db
        database = openOrCreateDatabase("gynaecology", Context.MODE_PRIVATE, null);

        //creating table if doesn't exist
        database.execSQL("CREATE TABLE IF NOT EXISTS gyno_familyhistory (" + table_query + ")");


    }

    @Override
    public void onBackPressed() { }

    public void onProceed(View view) {
        if (ValidationSuccess()) {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
            String format = simpleDateFormat.format(new Date());
            String diaf= "Not Specified", hypf = "Not Specified", tb2 = "Not Specified",mlg ="Not Specified";
            if(d1.isChecked())
                diaf=d_box.getText().toString().trim();
            if(h1.isChecked())
                hypf=h_box.getText().toString().trim();
            if(t1.isChecked())
                tb2=t_box.getText().toString().trim();
            if(m1.isChecked())
                mlg=m_box.getText().toString().trim();
            String insert_query = "'" + id.toString().trim() + "'," +
                    "'" + diaf + "'," +
                    "'" + hypf + "'," +
                    "'" + tb2 + "'," +
                    "'" + mlg + "'," +
                    "'" + others.getText().toString().trim() + "'," +
                    "'" + "No" + "'," +
                    "'" + format.toString().trim() + "'";
            System.out.println("InsertQuery:" + insert_query);
            //inserting into database
            database.execSQL("INSERT INTO gyno_familyhistory VALUES (" + insert_query + ")");
            Toast.makeText(getApplicationContext(), "Successful", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(getApplicationContext(), personal_history13.class);
            startActivity(intent);

        } else {
            Toast.makeText(getApplicationContext(), "Please check the details", Toast.LENGTH_LONG).show();
        }
        database.close();


    }
    private boolean ValidationSuccess(){

        boolean check=true;
        StringBuilder errMsg = new StringBuilder("");
        if (rg1.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg2.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg3.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg4.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if(d1.isChecked())
        {
            if (d_box.getText().toString().equalsIgnoreCase("")){
                d_box.setError("Please enter a value");
                check=false;
            }
        }

        if(h1.isChecked())
        {
            if (h_box.getText().toString().equalsIgnoreCase("")){
                h_box.setError("Please enter a value");
                check=false;
            }
        }

        if(t1.isChecked())
        {
            if (t_box.getText().toString().equalsIgnoreCase("")){
                t_box.setError("Please enter a value");
                check=false;
            }
        }

        if(m1.isChecked())
        {
            if (m_box.getText().toString().equalsIgnoreCase("")){
                m_box.setError("Please enter a value");
                check=false;
            }
        }
        if(others.getText().toString().equalsIgnoreCase("")){
            others.setError("Please enter a value");
            check=false;
        }

        return check;
    }
    public void click(View view)
    {
        d_box.setVisibility(View.VISIBLE);

    }
    public void click1(View view)
    {
        d_box.setVisibility(View.GONE);

    }
    public void click2(View view)
    {
        h_box.setVisibility(View.VISIBLE);

    }
    public void click3(View view)
    {
        h_box.setVisibility(View.GONE);

    }
    public void click4(View view)
    {
        t_box.setVisibility(View.VISIBLE);

    }
    public void click5(View view)
    {
        t_box.setVisibility(View.GONE);

    }
    public void click6(View view)
    {
        m_box.setVisibility(View.VISIBLE);

    }
    public void click7(View view)
    {
        m_box.setVisibility(View.GONE);

    }

}
