package com.example.apple.gynocare4;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import com.example.mathanky.gynocare4.R;
import com.example.apple.gynocare4.gynaec_systemic_examination;

import java.text.SimpleDateFormat;
import java.util.Date;
import static com.example.apple.gynocare4.generalinfo.id;

public class gynaec_general_physical_examination extends AppCompatActivity {

    SQLiteDatabase database;
    String table_gynaec_general_physical_examination="patient_id TEXT , gynaec_height TEXT , gynaec_weight TEXT , gynaec_bmi TEXT , gynaec_temp TEXT , gynaec_pr TEXT , gynaec_bp TEXT , gynaec_thyroid TEXT , gynaec_breasts TEXT , gynaec_spine TEXT , gynaec_pallor TEXT ,  gynaec_icterus TEXT , gynaec_cyanosis TEXT , gynaec_clubbing TEXT , gynaec_lymphadenopathy TEXT , gynaec_edema TEXT ,update_status TEXT DEFAULT \"No\", timestamp TEXT ,primary key(patient_id), foreign key(patient_id) references general_information(patient_id)";
    EditText ht,wt,bmi,pul,bp,thyroid_box,breasts_box,spine_box,pallor_box,icterus_box,cyanosis_box, clubbing_box, lymph_box, edema_box;
    RadioButton t1,b1,s1,p1,i1,c1,cl1,l1,e1,temp1,temp2;
    Button btnNext;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gynaec_general_physical_examination);
        database = openOrCreateDatabase("gynaecology", Context.MODE_PRIVATE, null);
        database.execSQL("CREATE TABLE IF NOT EXISTS gynaec_general_physical_examination(" + table_gynaec_general_physical_examination + ")");
        ht=(EditText)findViewById(R.id.g_height);
        wt=(EditText)findViewById(R.id.g_weight);
        bmi=(EditText)findViewById(R.id.g_BMI);
        pul=(EditText)findViewById(R.id.g_pulse);
        bp=(EditText)findViewById(R.id.g_BP);
        thyroid_box=(EditText)findViewById(R.id.g_thyroid_box);
        breasts_box=(EditText)findViewById(R.id.g_breasts_box);
        spine_box=(EditText)findViewById(R.id.g_spine_box);
        pallor_box=(EditText)findViewById(R.id.g_pallor_box);
        icterus_box=(EditText)findViewById(R.id.g_icterus_box);
        cyanosis_box=(EditText)findViewById(R.id.g_thyroid_box);
        clubbing_box=(EditText)findViewById(R.id.g_thyroid_box);
        lymph_box=(EditText)findViewById(R.id.g_thyroid_box);
        edema_box=(EditText)findViewById(R.id.g_thyroid_box);
        t1=(RadioButton)findViewById(R.id.g_thyroid_absent);
        b1=(RadioButton)findViewById(R.id.g_breasts_abnormal);
        s1=(RadioButton)findViewById(R.id.g_spine_abnormal);
        p1=(RadioButton)findViewById(R.id.g_pallor_normal);
        i1=(RadioButton)findViewById(R.id.g_icterus_normal);
        c1=(RadioButton)findViewById(R.id.g_cyanosis_normal);
        cl1=(RadioButton)findViewById(R.id.g_clubbing_normal);
        l1=(RadioButton)findViewById(R.id.g_lymph_normal);
        e1=(RadioButton)findViewById(R.id.g_edema_normal);
        temp1=(RadioButton)findViewById(R.id.g_temp_febrile);
        temp2=(RadioButton)findViewById(R.id.g_temp_afebrile);
        btnNext=(Button)findViewById(R.id.next_page14);
        thyroid_box.setVisibility(View.GONE);
        breasts_box.setVisibility(View.GONE);
        spine_box.setVisibility(View.GONE);
        pallor_box.setVisibility(View.GONE);
        icterus_box.setVisibility(View.GONE);
        cyanosis_box.setVisibility(View.GONE);
        clubbing_box.setVisibility(View.GONE);
        lymph_box.setVisibility(View.GONE);
        edema_box.setVisibility(View.GONE);
        onButton();
    }

    @Override
    public void onBackPressed() { }

    public void onButton()
    {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
        final String format = simpleDateFormat.format(new Date());
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(ValidationSuccess())
                {
                    String temp="",t="Normal",b="Normal",s="Normal",pal="Absent",ict="Absent",cya="Absent",clu="Absent",lym="Absent",ede="Absent";
                    if(temp1.isChecked())
                        temp="Febrile";
                    else if(temp2.isChecked())
                        temp="Afebrile";
                    if(t1.isChecked())
                        t=thyroid_box.getText().toString();
                    if(b1.isChecked())
                        b=breasts_box.getText().toString();
                    if(s1.isChecked())
                        s=spine_box.getText().toString();
                    if(p1.isChecked())
                        pal=pallor_box.getText().toString();
                    if(i1.isChecked())
                        ict=icterus_box.getText().toString();
                    if(c1.isChecked())
                        cya=cyanosis_box.getText().toString();
                    if(cl1.isChecked())
                        clu=clubbing_box.getText().toString();
                    if(l1.isChecked())
                        lym=lymph_box.getText().toString();
                    if(e1.isChecked())
                        ede=edema_box.getText().toString();
                    String insert_gynaec_general_physical_examination="'"+id.toString().trim()+"','"+ht.getText().toString().trim()+"','"+wt.getText().toString().trim()+"','"+bmi.getText().toString().trim()+"','"+temp.trim()+"','"+pul.getText().toString().trim()+"','"+bp.getText().toString().trim()+"','"+t.trim()+"','"+b.trim()+"','"+s.trim()+"','"+pal.trim()+"','"+ict.trim()+"','"+cya.trim()+"','"+clu.trim()+"','"+lym.trim()+"','"+ede.trim()+"','"+"No"+"','"+format.toString().trim()+"'";
                    System.out.println("InsertQuery:" + insert_gynaec_general_physical_examination);
                    //inserting into database
                    database.execSQL("INSERT INTO gynaec_general_physical_examination VALUES (" + insert_gynaec_general_physical_examination + ")");
                    Toast.makeText(getApplicationContext(), "Successful", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getApplicationContext(), gynaec_systemic_examination.class);
                    startActivity(intent);

                }
                else
                {
                    Toast.makeText(getApplicationContext(), "Please check the details", Toast.LENGTH_LONG).show();
                }
                database.close();
                }
        });
    }
    private boolean ValidationSuccess()
    {

        boolean check=true;
        StringBuilder errMsg = new StringBuilder("");

        return check;
    }
    public void click(View view)
    {
        thyroid_box.setVisibility(View.GONE);
    }

    public void click1(View view)
    {
        thyroid_box.setVisibility(View.VISIBLE);
    }

    public void click2(View view)
    {
        breasts_box.setVisibility(View.GONE);
    }

    public void click3(View view)
    {
        breasts_box.setVisibility(View.VISIBLE);
    }

    public void click4(View view)
    {
        spine_box.setVisibility(View.GONE);
    }

    public void click5(View view)
    {
        spine_box.setVisibility(View.VISIBLE);
    }

    public void click6(View view)
    {
        pallor_box.setVisibility(View.GONE);
    }

    public void click7(View view)
    {
        pallor_box.setVisibility(View.VISIBLE);
    }

    public void click8(View view)
    {
        icterus_box.setVisibility(View.GONE);
    }

    public void click9(View view)
    {
        icterus_box.setVisibility(View.VISIBLE);
    }

    public void click10(View view)
    {
        cyanosis_box.setVisibility(View.GONE);
    }

    public void click11(View view)
    {
        cyanosis_box.setVisibility(View.VISIBLE);
    }

    public void click12(View view)
    {
        clubbing_box.setVisibility(View.GONE);
    }

    public void click13(View view)
    {
        clubbing_box.setVisibility(View.VISIBLE);
    }

    public void click14(View view)
    {
        lymph_box.setVisibility(View.GONE);
    }

    public void click15(View view)
    {
        lymph_box.setVisibility(View.VISIBLE);
    }

    public void click16(View view)
    {
        edema_box.setVisibility(View.GONE);
    }

    public void click17(View view)
    {
        edema_box.setVisibility(View.VISIBLE);
    }

}
